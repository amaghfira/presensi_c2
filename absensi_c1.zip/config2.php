<?php
// SQL Server details 
// edit this file if you change the db
$sql_details = array(
    'user' => 'root',
    'pass' => '',
    'db' => 'absensi_c1',
    'host' => 'localhost'
);

$conn = $sql_details;
?>