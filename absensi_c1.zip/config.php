<?php 
// isi nama host, username mysql, dan password mysql anda
$host = mysqli_connect("bpskaltim.com","u8152743_ipd","ipd@6400", "u8152743_absensi_c1");

if($host){
	// echo "koneksi host berhasil.<br/>";
}else{
	// echo "koneksi gagal.<br/>";
}
// isikan dengan nama database yang akan di hubungkan
$db = mysqli_select_db($host,"absensi_c1");

// if($db){
// 	echo "koneksi database berhasil.";
// }else{
// 	echo "koneksi database gagal.";
// }
?>